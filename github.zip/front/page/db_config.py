db_config = {
    'user': 'root',
    'password': 'qwe',
    'host': 'localhost',
    'database': 'user_db'
}